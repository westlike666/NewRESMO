function kdr=kDR(T)
    kdr=6.91e-3*T.^(-0.5146);
end