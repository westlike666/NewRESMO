function kpd=kPD(n)
    kpd=arrayfun(@kPD_h, n);
end